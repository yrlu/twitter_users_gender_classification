function [Yhat, YProb] = a_ensemble_trees_predict(model, test_x)
[Yhat, YProb]= predict(model,test_x);
end
