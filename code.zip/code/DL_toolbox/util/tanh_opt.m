function  f=tanh_opt(A)
    f=1.7159*tanh(2/3.*A);
end